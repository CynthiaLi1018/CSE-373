package deques;

public class LinkedDeque<T> extends AbstractDeque<T> {
    private int size;
    // IMPORTANT: Do not rename these fields or change their visibility.
    // We access these during grading to test your code.
    Node<T> front;
    Node<T> back;
    // Feel free to add any additional fields you may need, though.

    public LinkedDeque() {
        size = 0;
        front = new Node<>(null, null, null);
        back = new Node<>(null, front, null);
        front.next = back;
    }

    public void addFirst(T item) {
        size += 1;
        front.next = new Node<>(item, front, front.next);
        front.next.next.prev = front.next;
    }

    public void addLast(T item) {
        size += 1;
        back.prev = new Node<>(item, back.prev, back);
        back.prev.prev.next= back.prev;
    }

    public T removeFirst() {
        if (size == 0) {
            return null;
        }
        size -= 1;
        T result = front.next.value;
        front.next.next.prev = front;
        front.next = front.next.next;
        return result;
    }

    public T removeLast() {
        if (size == 0) {
            return null;
        }
        size -= 1;
        T result = back.prev.value;
        back.prev.prev.next = back;
        back.prev = back.prev.prev;
        return result;
    }

    public T get(int index) {
        if ((index >= size) || (index < 0)) {
            return null;
        }
        if (index < size / 2) {
            Node<T> current = front.next;
            while (index > 0) {
                current = current.next;
                index -= 1;
            }
            return current.value;
        } else {
            Node<T> current = back.prev;
            while (size - index - 1> 0) {
                current = current.prev;
                index += 1;
            }
            return current.value;
        }
    }

    public int size() {
        return size;
    }
}
