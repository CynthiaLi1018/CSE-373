package priorityqueues;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.HashMap;

/**
 * @see ExtrinsicMinPQ
 */
public class ArrayHeapMinPQ<T> implements ExtrinsicMinPQ<T> {
    // IMPORTANT: Do not rename these fields or change their visibility.
    // We access these during grading to test your code.
    static final int START_INDEX = 1;
    List<PriorityNode<T>> items;
    HashMap<T, Integer> map;


    public ArrayHeapMinPQ() {
        map = new HashMap<>();
        items = new ArrayList<>();
        for (int i = 0; i < START_INDEX; i++) {
            items.add(null);
        }
    }

    // Here's a method stub that may be useful. Feel free to change or remove it, if you wish.
    // You'll probably want to add more helper methods like this one to make your code easier to read.
    /**
     * A helper method for swapping the items at two indices of the array heap.
     */
    private void swap(int a, int b) {
        PriorityNode<T> itemA = items.get(a);
        map.replace(itemA.getItem(), b);
        map.replace(items.get(b).getItem(), a);
        items.set(a, items.get(b));
        items.set(b, itemA);
    }

    private int leftChildIndex(int index) {
        return index * 2;
    }

    private int rightChildIndex(int index) {
        return index * 2 + 1;
    }

    private int parentIndex(int index) {
        return index / 2;
    }

    private int smallerChildIndex(int index) {
        int left = leftChildIndex(index);
        int right = rightChildIndex(index);
        if (size() < right) {
            index = leftChildIndex(index);
        } else {
            double leftPriority = items.get(left).getPriority();
            double rightPriority = items.get(right).getPriority();
            if (rightPriority < leftPriority) {
                index = right;
            } else {
                index = left;
            }
        }
        return index;
    }

    private void percolateUp(int index) {
        int parentIndex = parentIndex(index);
        while (parentIndex(index) >= START_INDEX &&
            !(items.get(index).getPriority() > items.get(parentIndex).getPriority())) {
            swap(index, parentIndex);
            index = parentIndex;
            parentIndex = parentIndex(index);
        }
    }

    private void percolateDown(int index) {
        int smallerChildIndex = smallerChildIndex(index);
        while (leftChildIndex(index) <= size() &&
            !(items.get(index).getPriority() < items.get(smallerChildIndex).getPriority())) {
            swap(index, smallerChildIndex);
            index = smallerChildIndex;
            smallerChildIndex = smallerChildIndex(index);
        }
    }

    @Override
    public void add(T item, double priority) {
        if (Objects.equals(item, null) || contains(item)) {
            throw new IllegalArgumentException();
        }
        items.add(new PriorityNode<>(item, priority));
        int index = size();
        map.put(item, index);
        percolateUp(index);
    }

    @Override
    public boolean contains(T item) {
        return map.containsKey(item);
    }

    @Override
    public T peekMin() {
        if (size() == 0) {
            throw new NoSuchElementException();
        }
        return items.get(START_INDEX).getItem();
    }

    @Override
    public T removeMin() {
        if (size() == 0) {
            throw new NoSuchElementException();
        }
        T result = peekMin();
        PriorityNode<T> lastNode = items.get(size());
        items.set(START_INDEX, lastNode);
        items.remove(size());
        map.remove(result);
        map.replace(lastNode.getItem(), START_INDEX);
        percolateDown(START_INDEX);
        return result;
    }

    @Override
    public void changePriority(T item, double priority) {
        if (!contains(item)) {
            throw new NoSuchElementException();
        }
        int indexAt = map.get(item);
        double previousPriority = items.get(indexAt).getPriority();
        items.set(indexAt, new PriorityNode<T>(item, priority));
        if (priority > previousPriority) {
            percolateDown(indexAt);
        } else if (priority < previousPriority) {
            percolateUp(indexAt);
        }
    }


    @Override
    public int size() {
        return items.size() - START_INDEX;
    }
}
