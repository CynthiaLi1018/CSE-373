package maps;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * @see AbstractIterableMap
 * @see Map
 */
public class ChainedHashMap<K, V> extends AbstractIterableMap<K, V> {
    private static final double DEFAULT_RESIZING_LOAD_FACTOR_THRESHOLD = 1.5;
    private static final int DEFAULT_INITIAL_CHAIN_COUNT = 10;
    private static final int DEFAULT_INITIAL_CHAIN_CAPACITY = 10;

    /*
    Warning:
    You may not rename this field or change its type.
    We will be inspecting it in our secret tests.
     */
    AbstractIterableMap<K, V>[] chains;

    // You're encouraged to add extra fields (and helper methods) though!
    private double loadFactor;
    private int buckets;
    private int capacity;
    private int size;

    public ChainedHashMap() {
        this(DEFAULT_RESIZING_LOAD_FACTOR_THRESHOLD, DEFAULT_INITIAL_CHAIN_COUNT, DEFAULT_INITIAL_CHAIN_CAPACITY);
    }

    public ChainedHashMap(double resizingLoadFactorThreshold, int initialChainCount, int chainInitialCapacity) {
        chains = createArrayOfChains(initialChainCount);
        loadFactor = resizingLoadFactorThreshold;
        buckets = initialChainCount;
        capacity = chainInitialCapacity;
    }

    /**
     * This method will return a new, empty array of the given size that can contain
     * {@code AbstractIterableMap<K, V>} objects.
     *
     * Note that each element in the array will initially be null.
     *
     * Note: You do not need to modify this method.
     * @see ArrayMap createArrayOfEntries method for more background on why we need this method
     */
    @SuppressWarnings("unchecked")
    private AbstractIterableMap<K, V>[] createArrayOfChains(int arraySize) {
        return (AbstractIterableMap<K, V>[]) new AbstractIterableMap[arraySize];
    }

    /**
     * Returns a new chain.
     *
     * This method will be overridden by the grader so that your ChainedHashMap implementation
     * is graded using our solution ArrayMaps.
     *
     * Note: You do not need to modify this method.
     */
    protected AbstractIterableMap<K, V> createChain(int initialSize) {
        return new ArrayMap<>(initialSize);
    }

    private int getIndex(Object key) {
        int index = 0;
        if (!Objects.equals(key, null)) {
            int hashCode = Math.abs(key.hashCode());
            index = hashCode % buckets;
        }
        return index;
    }

    @Override
    public V get(Object key) {
        AbstractIterableMap<K, V> map = chains[getIndex(key)];
        if (Objects.equals(map, null)) {
            return null;
        }
        return map.get(key);
    }

    @Override
    public V put(K key, V value) {
        if (!containsKey(key)) {
            size++;
        }
        int index = getIndex(key);
        AbstractIterableMap<K, V> map = chains[index];
        if (Objects.equals(map, null)) {
            map = createChain(capacity);
        }
        V result = map.put(key, value);
        chains[index] = map;
        if ((double) size / buckets > loadFactor) {
            buckets = 2 * buckets;
            AbstractIterableMap<K, V>[] clone = chains.clone();
            chains = createArrayOfChains(buckets);
            size = 0;
            for (int i = 0; i < buckets / 2; i++) {
                if (!Objects.equals(clone[i], null)) {
                    for (Entry<K, V> current : clone[i]) {
                        put(current.getKey(), current.getValue());
                    }
                }
            }
        }
        return result;
    }

    @Override
    public V remove(Object key) {
        if (!containsKey(key)) {
            return null;
        }
        size--;
        return chains[getIndex(key)].remove(key);
    }

    @Override
    public void clear() {
        chains = createArrayOfChains(buckets);
        size = 0;
    }

    @Override
    public boolean containsKey(Object key) {
        AbstractIterableMap<K, V> map = chains[getIndex(key)];
        if (Objects.equals(map, null)) {
            return false;
        }
        return map.containsKey(key);
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<Map.Entry<K, V>> iterator() {
        // Note: you won't need to change this method (unless you add more constructor parameters)
        return new ChainedHashMapIterator<>(this.chains);
    }


    /*
    See the assignment webpage for tips and restrictions on implementing this iterator.
     */
    private static class ChainedHashMapIterator<K, V> implements Iterator<Map.Entry<K, V>> {
        private AbstractIterableMap<K, V>[] chains;
        // You may add more fields and constructor parameters
        private Iterator<Entry<K, V>> current;
        private int index;

        public ChainedHashMapIterator(AbstractIterableMap<K, V>[] chains) {
            this.chains = chains;
            for (int i = 0; i < chains.length; i++) {
                if (!Objects.equals(chains[i], null)) {
                    current = chains[i].iterator();
                    index = i;
                    break;
                }
            }
        }

        @Override
        public boolean hasNext() {
            if (current != null && current.hasNext()) {
                return true;
            } else {
                if (Objects.equals(index, chains.length - 1)) {
                    return false;
                } else {
                    index++;
                    if (chains[index] != null) {
                        current = chains[index].iterator();
                    } else {
                        current = null;
                    }
                    return hasNext();
                }
            }
        }

        @Override
        public Map.Entry<K, V> next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            if (!current.hasNext() && chains[index + 1] != null) {
                index = index + 1;
                current = chains[index].iterator();
            }
            return current.next();
        }
    }
}
