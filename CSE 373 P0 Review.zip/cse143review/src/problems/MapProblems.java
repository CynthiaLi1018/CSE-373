package problems;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * See the spec on the website for example behavior.
 */
public class MapProblems {

    /**
     * Returns true if any string appears at least 3 times in the given list; false otherwise.
     */
    @SuppressWarnings("checkstyle:EmptyBlock")
    public static boolean contains3(List<String> list) {
        if (!list.isEmpty()) {
            Map<String, Integer> countWord = new HashMap<>();
            for (String phrase : list) {
                if (countWord.containsKey(phrase)) {
                    countWord.put(phrase, countWord.get(phrase) + 1);
                } else {
                    countWord.put(phrase, 1);
                }
            }
            for (String phrase : countWord.keySet()) {
                if (countWord.get(phrase) >= 3) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }


    /**
     * Returns a map containing the intersection of the two input maps.
     * A key-value pair exists in the output iff the same key-value pair exists in both input maps.
     */
    public static Map<String, Integer> intersect(Map<String, Integer> m1, Map<String, Integer> m2) {
        Map<String, Integer> intersect = new HashMap<>();
        if (!m1.isEmpty() && !m2.isEmpty()) {
            int size1 = m1.keySet().size();
            int size2 = m2.keySet().size();
            // could make it faster when the size of m1 and m2 is significantly different,
            // otherwise just use line 50 - 54 to search one map's keys in the other map's
            // keyset and check if the corresponding value is the same.
            if (size1 >= size2) {
                for (String name : m2.keySet()) {
                    if (m1.containsKey(name) && m2.get(name).equals(m1.get(name))) {
                        intersect.put(name, m2.get(name));
                    }
                }
            } else {
                for (String name : m1.keySet()) {
                    if (m2.containsKey(name) && m1.get(name).equals(m2.get(name))) {
                        intersect.put(name, m1.get(name));
                    }
                }
            }
        }
        return intersect;
    }
}
