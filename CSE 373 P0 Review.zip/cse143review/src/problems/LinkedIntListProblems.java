package problems;

import datastructures.LinkedIntList;
// Checkstyle will complain that this is an unused import until you use it in your code.
import datastructures.LinkedIntList.ListNode;

/**
 * See the spec on the website for example behavior.
 *
 * REMEMBER THE FOLLOWING RESTRICTIONS:
 * - do not call any methods on the `LinkedIntList` objects.
 * - do not construct new `ListNode` objects for `reverse3` or `firstToLast`
 *      (though you may have as many `ListNode` variables as you like).
 * - do not construct any external data structures such as arrays, queues, lists, etc.
 * - do not mutate the `data` field of any node; instead, change the list only by modifying
 *      links between nodes.
 */

public class LinkedIntListProblems {

    /**
     * Reverses the 3 elements in the `LinkedIntList` (assume there are exactly 3 elements).
     */
    public static void reverse3(LinkedIntList list) {
        ListNode pre = list.front.next;
        ListNode cur = list.front.next.next;
        pre.next = null;
        cur.next = pre;
        list.front.next = null;
        cur.next.next = list.front;
        list.front = cur;
    }

    /**
     * Moves the first element of the input list to the back of the list.
     */
    public static void firstToLast(LinkedIntList list) {
        if (list.front != null && list.front.next != null) {
            ListNode cur = list.front.next;
            while (cur.next != null) {
                cur = cur.next;
            }
            cur.next = list.front;
            ListNode temp = list.front.next;
            list.front.next = null;
            list.front = temp;
        }
    }


    /**
     * Returns a list consisting of the integers of a followed by the integers
     * of n. Does not modify items of A or B.
     */
    public static LinkedIntList concatenate(LinkedIntList a, LinkedIntList b) {
        LinkedIntList list = new LinkedIntList();
        if (a.front == null) {
            list.front = b.front;
        } else if (b.front == null) {
            list.front = a.front;
        } else { // a != null && b!= null
            ListNode start = new ListNode(a.front.data);
            ListNode temp1 = start;
            ListNode temp2 = a.front;
            while (temp2.next != null) {
                temp1.next = new ListNode(temp2.next.data);
                temp2 = temp2.next;
                temp1 = temp1.next;
            }
            temp1.next = b.front;
            list.front = start;
        }
        return list;
    }
}
