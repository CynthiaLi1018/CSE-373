package disjointsets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.List;
import java.util.Set;

/**
 * A quick-union-by-size data structure with path compression.
 * @see DisjointSets for more documentation.
 */
public class UnionBySizeCompressingDisjointSets<T> implements DisjointSets<T> {
    // Do NOT rename or delete this field. We will be inspecting it directly in our private tests.
    List<Integer> pointers;

    /*
    However, feel free to add more fields and private helper methods. You will probably need to
    add one or two more fields in order to successfully implement this class.
    */
    Map<T, Integer> ids;
    int numberOfSets;

    public UnionBySizeCompressingDisjointSets() {
        pointers = new ArrayList<>();
        ids = new HashMap<>();
        numberOfSets = 0;
    }

    @Override
    public void makeSet(T item) {
        pointers.add(-1);
        ids.put(item, numberOfSets);
        numberOfSets++;
    }

    @Override
    public int findSet(T item) {
        if (!ids.containsKey(item)) {
            throw new IllegalArgumentException();
        }

        int index = ids.get(item);
        Set<Integer> passed = new HashSet<>();

        while (pointers.get(index) >= 0) {
            index = pointers.get(index);
        }

        int i = ids.get(item);

        while (pointers.get(i) >= 0) {
            pointers.set(i, index);
            i = pointers.get(i);
        }

        return index;
    }

    @Override
    public boolean union(T item1, T item2) {
        if (!ids.containsKey(item1) || !ids.containsKey(item2)) {
            throw new IllegalArgumentException();
        }

        int id1 = findSet(item1);
        int id2 = findSet(item2);

        if (id1 == id2) {
            return false;
        } else {
            if (pointers.get(id1) < pointers.get(id2)) {
                pointers.set(id2, id1);
                pointers.set(id1, pointers.get(id1) - 1);
            } else {
                pointers.set(id1, id2);
                pointers.set(id2, pointers.get(id2) - 1);
            }
            return true;
        }
    }
}
