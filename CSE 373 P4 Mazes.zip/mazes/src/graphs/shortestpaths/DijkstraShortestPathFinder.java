package graphs.shortestpaths;

import graphs.BaseEdge;
import graphs.Graph;
import priorityqueues.DoubleMapMinPQ;
import priorityqueues.ExtrinsicMinPQ;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Objects;
import java.util.List;

/**
 * Computes shortest paths using Dijkstra's algorithm.
 * @see SPTShortestPathFinder for more documentation.
 */
public class DijkstraShortestPathFinder<G extends Graph<V, E>, V, E extends BaseEdge<V, E>>
    extends SPTShortestPathFinder<G, V, E> {

    protected <T> ExtrinsicMinPQ<T> createMinPQ() {
        return new DoubleMapMinPQ<>();
        /*
        If you have confidence in your heap implementation, you can disable the line above
        and enable the one below.
         */
        // return new ArrayHeapMinPQ<>();

        /*
        Otherwise, do not change this method.
        We override this during grading to test your code using our correct implementation so that
        you don't lose extra points if your implementation is buggy.
         */
    }

    @Override
    protected Map<V, E> constructShortestPathsTree(G graph, V start, V end) {
        Map<V, E> edgeTo = new HashMap<>();
        if (Objects.equals(start, end)) {
            return edgeTo;
        }
        ExtrinsicMinPQ<V> perimeter = createMinPQ();
        Map<V, Double> distTo = new HashMap<>();
        distTo.put(start, 0.00);
        perimeter.add(start, 0.00);
        while (!perimeter.isEmpty()) {
            V from = perimeter.removeMin();
            for (E edge : graph.outgoingEdgesFrom(from)) {
                V to = edge.to();
                double newDist = distTo.get(from) + edge.weight();
                if (!distTo.containsKey(to)) {
                    distTo.put(to, newDist);
                    edgeTo.put(to, edge);
                    perimeter.add(to, newDist);
                } else {
                    double oldDist = distTo.get(to);
                    if (newDist < oldDist) {
                        distTo.replace(to, newDist);
                        edgeTo.replace(to, edge);
                        if (perimeter.contains(to)) {
                            perimeter.changePriority(to, newDist);
                        }
                    }
                }
                if (distTo.containsKey(end) && !perimeter.contains(end)) {
                    break;
                }
            }
        }
        return edgeTo;
    }

    @Override
    protected ShortestPath<V, E> extractShortestPath(Map<V, E> spt, V start, V end) {
        if (Objects.equals(start, end)) {
            return new ShortestPath.SingleVertex<>(start);
        }
        if (!spt.containsKey(end)) {
            return new ShortestPath.Failure<>();
        }
        List<E> edges = new LinkedList<>();
        V soFar = end;
        while (!Objects.equals(soFar, start)) {
            E edge = spt.get(soFar);
            edges.add(0, edge);
            soFar = edge.from();
        }
        return new ShortestPath.Success<>(edges);
    }
}
